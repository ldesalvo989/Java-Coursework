/*
Lauren DeSalvo
Assignment 2 - URL Encoding a String
June 4, 2018
 */
package assignment2;

import java.util.Scanner;

/**
 *
 */
public class Assignment2 {

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
       Scanner keyboard = new Scanner(System.in);
       
       
       System.out.println("Enter a line of text to be URL encoded");
       
       String sentence;
        
       sentence = keyboard.nextLine();
        System.out.println("The string read is:  " + sentence);
        
        int n = sentence.length();
        System.out.println("Length in chars is: " + n);
        
               
        
        String encoded = "";
        String test = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-_*";
        int count;
        int y;
               
         for (count = 0; count < sentence.length(); count++)  
         { 
             char x = sentence.charAt(count);
             String hexValue = Integer.toHexString((int) x);
             
             if (x == ' ' ) {
                encoded = encoded + '+';
             }        
                     
             else if (test.indexOf(x) != -1 ) {
                encoded =  encoded + x; 
             }
             else {
                encoded += '%' + hexValue;
             }
         } 
             
         
          y = encoded.length();
          System.out.println("The encode string: " + encoded);
          System.out.println("Length in chars is: " + y );
              
         }        

        
         
    }
    
